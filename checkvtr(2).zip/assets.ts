
export const DEFAULT_VEHICLE_IMAGES = {
  VTR: "https://stskgrcbkzketgowsdwq.supabase.co/storage/v1/object/public/vehicle-assets/vtr.jpg",
  MR: "https://stskgrcbkzketgowsdwq.supabase.co/storage/v1/object/public/vehicle-assets/mr.jpg"
};
